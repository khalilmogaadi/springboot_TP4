package com.khalil.album.entities;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "nomalb", types = { Album.class })

public interface AlbumProjection {
	public String getNomAlbum();


}
