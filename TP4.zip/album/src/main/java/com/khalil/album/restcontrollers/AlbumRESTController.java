package com.khalil.album.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.khalil.album.entities.Album;
import com.khalil.album.service.AlbumService;

@RestController
@RequestMapping("/api")
@CrossOrigin

public class AlbumRESTController {
	@Autowired
	AlbumService albumService;
	@RequestMapping(method = RequestMethod.GET)
	public List<Album> getAllAlbums() {
	return albumService.getAllAlbums();
	}
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public Album getAlbumById(@PathVariable("id") Long id) {
	return albumService.getAlbum(id);
	 }
	@RequestMapping(method = RequestMethod.POST)
	public Album createAlbum(@RequestBody Album album) {
		return albumService.saveAlbum(album);
	}
	@RequestMapping(method = RequestMethod.PUT)
	public Album updateAlbum(@RequestBody Album album) {
	return albumService.updateAlbum(album);
	}
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
	public void deleteAlbum(@PathVariable("id") Long id)
	{
		albumService.deleteAlbumById(id);
	}
	@RequestMapping(value="/albmGen/{idGen}",method = RequestMethod.GET)
	public List<Album> getAlbumByGenId(@PathVariable("idGen") Long idGen) {
	return albumService.findByGenreIdGen(idGen);
	}
}
